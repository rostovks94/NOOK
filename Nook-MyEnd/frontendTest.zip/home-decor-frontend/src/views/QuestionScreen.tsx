import React from 'react';

const QuestionScreen: React.FC = () => {
  return (
    <div>
      <h1>Question Screen Placeholder</h1>
    </div>
  );
};

export default QuestionScreen;