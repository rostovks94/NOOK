import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import '../css/CompleteSignUp.css';

const CompleteSignUp: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email || ''; 
  const [username, setUsername] = useState<string>(''); // Добавили state для username
  const [password, setPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [error, setError] = useState<string>(''); 
  const [loading, setLoading] = useState<boolean>(false);

  if (!email) {
    navigate('/register');
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(''); 
    if (password !== confirmPassword) {
      setError('Passwords do not match!');
      return;
    }

    try {
      setLoading(true); 
      console.log('User created with email:', email);
      navigate('/main-feed');
    } catch (err: any) {
      console.error('Registration failed:', err);
      setError('Failed to create account');
    } finally {
      setLoading(false); 
    }
  };

  return (
    <div className="complete-signup-page">
      <div className="complete-signup-overlay"></div> 
      <form className="complete-signup-content" onSubmit={handleSubmit}>
        <div className="register-logo"></div>
        {error && <p className="error-message">{error}</p>}
        <div className="input-container">
          <label>Email</label>
          <input type="email" value={email} readOnly />
        </div>
        <div className="input-container">
          <label>Username</label> {/* Поле Username */}
          <input
            type="text"
            placeholder="Enter Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="input-container">
          <label>Create Password</label>
          <input
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="input-container">
          <label>Confirm Password</label>
          <input
            type="password"
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="create-account-button" disabled={loading}>
          {loading ? 'Creating Account...' : 'Create Account'}
        </button>
      </form>
    </div>
  );
};

export default CompleteSignUp;