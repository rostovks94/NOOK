import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../css/Register.css';

const Register: React.FC = () => {
  const navigate = useNavigate();

  const handleSignUp = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Вместо реальной логики регистрации, просто переходим на страницу complete-signup
    navigate('/complete-signup', { state: { email: 'example@example.com' } });
  };

  const handleLogin = () => {
    // Переход на страницу логина
    navigate('/login');
  };

  return (
    <div className="register-page">
      <div className="register-overlay"></div>
      <div className="register-page-content">
        <div className="register-logo"></div>
        <p className="info-message">Registration is currently a placeholder. You can proceed to the next step.</p>

        <form onSubmit={handleSignUp}>
          <div className="register-input-container">
            <label>Email</label>
            <input
              type="email"
              placeholder="Введите Email"
              required
            />
          </div>

          <button type="submit" className="register-create-account-button">
            Sign Up
          </button>

          <div className="register-divider">
            <span>OR</span>
          </div>

          <button type="button" className="register-google-signup-button" disabled>
            Sign Up with Google 
          </button>

          <button type="button" className="register-login-button" onClick={handleLogin}>
            Login
          </button>
        </form>
      </div>
    </div>
  );
};

export default Register;